#sss
iptables -t nat -F
iptables -t nat -X